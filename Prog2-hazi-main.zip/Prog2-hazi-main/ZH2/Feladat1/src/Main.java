//import java.util.List;
//
//public class Main {
//    public static void main(String[] args) {
//        Hallgato hallgato1 = new Hallgato("RNK0I2");
//        hallgato1.addSubjects(List.of(1, 3, 5, 7, 9, 12));
//        Hallgato hallgato2 = new Hallgato("K9R3MN");
//        hallgato2.addSubjects(List.of(2, 8, 11, 10, 5, 6));
//        Hallgato hallgato3 = new Hallgato("IJKRST");
//        hallgato3.addSubjects(List.of(3, 5, 4, 7, 9, 12));
//        Hallgato hallgato4 = new Hallgato("EUQOW0");
//        hallgato4.addSubjects(List.of(3, 5, 4, 7, 9, 10));
//
//
//        Hallgatok hallgatok = new Hallgatok();
//        hallgatok.add(hallgato1);
//        hallgatok.add(hallgato2);
//        hallgatok.add(hallgato3);
//        hallgatok.add(hallgato4);
//        Hallgatok.findClassmates("K9R3MN");
//    }
//}
