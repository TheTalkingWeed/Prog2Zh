

public class Negyzet {

        public static int kerulet(int oldal){
            return oldal*4;
        }

        public  static int terulet(int oldal){
            return oldal*oldal;
        }



    }

