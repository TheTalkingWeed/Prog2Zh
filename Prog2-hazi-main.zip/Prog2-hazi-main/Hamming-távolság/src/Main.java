class Main{
    public static void main(String[] args) {

        int diff = Hamming.distance("toned", "roses");
        
        System.out.println(diff);

    }
}